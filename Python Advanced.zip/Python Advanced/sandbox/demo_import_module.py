from exercise_doctest import cube

print(cube(4))
